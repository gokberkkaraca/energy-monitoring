You can create your own accounts to test the application or you can use our test account too;

Google Account: dwarf.sleepy2017@gmail.com
Password: sleepydwarf2017